import {get,post}from `./api.js`
import { clearUserData, setUserData } from "./userInfo.js";
let url = "http://localhost:3030/users";
let options = {
    login: "/login",
    register: "/register",
    logout: "/logout"
}
export async function login(email,password){
    let userData = await post(url + options.login,{email,password});
    setUserData(userData);
    return userData;
}

export async function register(email,password){
    let userData = await post(url + options.register,{email,password});
    setUserData(userData);
    return userData;
}
export async function logout(){
    await get(url + options.logout);
    clearUserData();
    return;
}